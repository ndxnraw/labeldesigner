﻿using System.Reflection;
[assembly: AssemblyTitle("ND LabelMaker")]
[assembly: AssemblyDescription("Editor etikiet a ciarovych kodov pre Windows")]
[assembly: AssemblyVersion("2.4.0.0")]
[assembly: AssemblyFileVersion("2.4.0.0")]

[assembly: AssemblyProduct("ND LabelMaker")]
