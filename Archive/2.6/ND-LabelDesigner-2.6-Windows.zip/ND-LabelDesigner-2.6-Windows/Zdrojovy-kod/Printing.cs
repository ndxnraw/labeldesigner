﻿using System;using System.Drawing;using System.Drawing.Printing;using System.Windows.Forms;
namespace EanEtikety {
public class LabelPrintDocument:PrintDocument {
 readonly LabelSettings label;readonly VectorScene scene;int page;
 public int PageCount {get{return 1;}}
 public int Capacity {get{return 1;}}
 public double WidthMm {get{return (label.UsePaper||label.Sheet)?label.PageWidth:label.Width;}}
 public double HeightMm {get{return (label.UsePaper||label.Sheet)?label.PageHeight:label.Height;}}
 public LabelPrintDocument(LabelSettings settings){Engine.Validate(settings);label=settings;scene=VectorArt.Build(settings);DocumentName="ND LabelDesigner";OriginAtMargins=false;
  DefaultPageSettings.Margins=new Margins(0,0,0,0);DefaultPageSettings.Landscape=false;
  DefaultPageSettings.PaperSize=new PaperSize("ND LabelDesigner",(int)Math.Round(WidthMm/25.4*100),(int)Math.Round(HeightMm/25.4*100));PrinterSettings.Copies=1;
 }
 public RectangleF LabelBounds(int index){int cols=Engine.Columns(label);return new RectangleF((float)(label.UsePaper||label.Sheet?label.MarginX:0),(float)(label.UsePaper||label.Sheet?label.MarginY:0),(float)label.Width,(float)label.Height);}
 public int RenderPage(Graphics g,int pageIndex){if(pageIndex<0||pageIndex>=PageCount)throw new ArgumentOutOfRangeException("pageIndex");var saved=g.Save();try{g.PageUnit=GraphicsUnit.Millimeter;g.PageScale=1;int count=1;for(int i=0;i<count;i++)scene.Draw(g,LabelBounds(i),false);return count;}finally{g.Restore(saved);}}
 public bool FitsPaper(Rectangle bounds){return bounds.Width*25.4/100+.5>=WidthMm&&bounds.Height*25.4/100+.5>=HeightMm;}
 public bool ContentFits(RectangleF printable){var area=new RectangleF(printable.X*.254f,printable.Y*.254f,printable.Width*.254f,printable.Height*.254f);area.Inflate(.15f,.15f);for(int i=0;i<Math.Min(Capacity,label.Copies);i++){var pos=LabelBounds(i);foreach(var shape in scene.Shapes){var b=RectangleF.Intersect(shape.Path.GetBounds(),shape.Clip);b=RectangleF.Intersect(b,new RectangleF(0,0,(float)label.Width,(float)label.Height));if(b.IsEmpty)continue;b.Offset(pos.X,pos.Y);if(!area.Contains(b))return false;}}return true;}
 protected override void OnBeginPrint(PrintEventArgs e){page=0;base.OnBeginPrint(e);}
 protected override void OnPrintPage(PrintPageEventArgs e){if(!FitsPaper(e.PageBounds))throw new InvalidOperationException(Loc.T("Papier tlačiarne je menší než nastavený formát. Upravte formát v nastavení tlačiarne."));var graphicsState=e.Graphics.Save();try{e.Graphics.ResetTransform();e.Graphics.PageUnit=GraphicsUnit.Millimeter;e.Graphics.PageScale=1;if(!PrintController.IsPreview)e.Graphics.TranslateTransform(-e.PageSettings.HardMarginX*.254f,-e.PageSettings.HardMarginY*.254f);RenderPage(e.Graphics,page++);}finally{e.Graphics.Restore(graphicsState);}e.HasMorePages=page<PageCount;base.OnPrintPage(e);}
 protected override void Dispose(bool disposing){if(disposing)scene.Dispose();base.Dispose(disposing);}
}
public partial class MainForm {
 void PrintLabel(){try{var s=Read();Engine.Validate(s);if(PrinterSettings.InstalledPrinters.Count==0)throw new InvalidOperationException(Loc.T("Vo Windows nie je nainštalovaná tlačiareň."));
  using(var document=new LabelPrintDocument(s))using(var dialog=new PrintDialog{Document=document,UseEXDialog=true,AllowSomePages=false,AllowSelection=false,AllowCurrentPage=false,AllowPrintToFile=false}){
   if(dialog.ShowDialog(this)!=DialogResult.OK)return;
   if(!document.PrinterSettings.IsValid)throw new InvalidOperationException(Loc.T("Vybraná tlačiareň nie je dostupná."));
   document.DefaultPageSettings.Margins=new Margins(0,0,0,0);
   if(!document.FitsPaper(document.DefaultPageSettings.Bounds))throw new InvalidOperationException(Loc.T("Papier tlačiarne je menší než nastavený formát. Upravte formát v nastavení tlačiarne."));
   var warnings=Engine.Warnings(s);if(!document.ContentFits(document.DefaultPageSettings.PrintableArea))warnings.Add(Loc.T("Časť obsahu je mimo tlačiteľnej oblasti tlačiarne a môže byť orezaná."));
   if(warnings.Count>0&&MessageBox.Show(this,string.Join("\r\n",warnings.ToArray())+"\r\n\r\n"+Loc.T("Pokračovať v tlači?"),Loc.T("Tlač"),MessageBoxButtons.YesNo,MessageBoxIcon.Warning)!=DialogResult.Yes)return;
   using(var window=new Form{Text=Loc.T("Náhľad pred tlačou"),Size=new Size(1000,850),StartPosition=FormStartPosition.CenterParent,Font=Font}){
    var previewControl=new PrintPreviewControl{Dock=DockStyle.Fill,Document=document,AutoZoom=true,UseAntiAlias=true};var bar=new FlowLayoutPanel{Dock=DockStyle.Top,Height=54};
    bar.Controls.Add(Btn(Loc.T("Tlačiť"),delegate{try{document.PrintController=new System.Windows.Forms.PrintControllerWithStatusDialog(new StandardPrintController());document.Print();status.Text=Loc.T("Úloha bola odoslaná do tlačového systému Windows.");window.Close();}catch(Exception ex){Error(ex);}}));bar.Controls.Add(Btn(Loc.T("Zrušiť"),delegate{window.Close();}));bar.Controls.Add(new Label{Text=Loc.T("Kópie:")+" "+document.PrinterSettings.Copies+"  |  "+document.WidthMm+" × "+document.HeightMm+" mm",AutoSize=true,Margin=new Padding(12,12,0,0)});window.Controls.Add(previewControl);window.Controls.Add(bar);window.ShowDialog(this);
   }
  }
 }catch(Exception ex){Error(ex);}}
}
}
