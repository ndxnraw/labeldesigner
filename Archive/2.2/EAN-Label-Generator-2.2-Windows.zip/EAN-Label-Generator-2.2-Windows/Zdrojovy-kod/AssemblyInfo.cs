﻿using System.Reflection;
[assembly: AssemblyTitle("EAN Label Generator")]
[assembly: AssemblyDescription("Editor etikiet a ciarovych kodov pre Windows")]
[assembly: AssemblyVersion("2.2.0.0")]
[assembly: AssemblyFileVersion("2.2.0.0")]

[assembly: AssemblyProduct("EAN Label Generator")]
