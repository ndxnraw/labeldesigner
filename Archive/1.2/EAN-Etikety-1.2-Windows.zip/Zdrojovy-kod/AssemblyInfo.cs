using System.Reflection;
[assembly: AssemblyTitle("EAN Etikety")]
[assembly: AssemblyDescription("Editor etikiet a ciarovych kodov pre Windows")]
[assembly: AssemblyVersion("1.2.0.0")]
[assembly: AssemblyFileVersion("1.2.0.0")]
