using System;using System.IO;using System.Text;using System.Drawing;using System.Drawing.Imaging;using System.Collections.Generic;using System.Globalization;
namespace EanEtikety {
public class WordPart {public int Number;public string Svg;public byte[] Png;public RectangleF Bounds;}
public static class WordParts {
 static string F(double x){return x.ToString("0.#####",CultureInfo.InvariantCulture);}
 public static List<WordPart> Create(LabelSettings s){var result=new List<WordPart>();using(var original=VectorArt.Build(s)){var keys=new List<int>();for(int i=0;i<s.Texts.Count;i++)keys.Add(i);keys.Add(-1);for(int i=0;i<s.Symbols.Count;i++)keys.Add(-3-i);
  foreach(int key in keys){using(var part=new VectorScene{Width=s.Width,Height=s.Height}){RectangleF bounds=RectangleF.Empty;foreach(var shape in original.Shapes)if(shape.Element==key&&shape.Path.PointCount>0){var clip=RectangleF.Intersect(shape.Clip,new RectangleF(0,0,(float)s.Width,(float)s.Height));var area=RectangleF.Intersect(clip,shape.Path.GetBounds());if(area.Width<=0||area.Height<=0)continue;bounds=bounds.IsEmpty?area:RectangleF.Union(bounds,area);part.Shapes.Add(new ArtShape{Path=(System.Drawing.Drawing2D.GraphicsPath)shape.Path.Clone(),Clip=clip,Bars=shape.Bars,Element=key});}if(bounds.IsEmpty)continue;
   var svg=new StringBuilder("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\""+F(bounds.Width)+"mm\" height=\""+F(bounds.Height)+"mm\" viewBox=\""+F(bounds.X)+" "+F(bounds.Y)+" "+F(bounds.Width)+" "+F(bounds.Height)+"\"><defs>");int n=0;foreach(var shape in part.Shapes){var c=shape.Clip;svg.Append("<clipPath id=\"c"+n+++"\"><rect x=\""+F(c.X)+"\" y=\""+F(c.Y)+"\" width=\""+F(c.Width)+"\" height=\""+F(c.Height)+"\"/></clipPath>");}svg.Append("</defs><g fill=\"black\" fill-rule=\"evenodd\">");n=0;foreach(var shape in part.Shapes)svg.Append("<path clip-path=\"url(#c"+n+++")\" d=\""+VectorArt.PathData(shape.Path,true)+"\"/>");svg.Append("</g></svg>");
   double dpi=Math.Min(600,Math.Sqrt(4000000*25.4*25.4/(bounds.Width*bounds.Height))),k=dpi/25.4;using(var bmp=new Bitmap(Math.Max(1,(int)Math.Ceiling(bounds.Width*k)),Math.Max(1,(int)Math.Ceiling(bounds.Height*k)),PixelFormat.Format32bppArgb)){bmp.SetResolution((float)dpi,(float)dpi);using(var g=Graphics.FromImage(bmp)){g.Clear(Color.Transparent);part.Draw(g,new RectangleF((float)(-bounds.X*k),(float)(-bounds.Y*k),(float)(s.Width*k),(float)(s.Height*k)),false);}using(var ms=new MemoryStream()){bmp.Save(ms,ImageFormat.Png);result.Add(new WordPart{Number=result.Count+1,Bounds=bounds,Svg=svg.ToString(),Png=ms.ToArray()});}}
  }}
 }return result;}
}
}
