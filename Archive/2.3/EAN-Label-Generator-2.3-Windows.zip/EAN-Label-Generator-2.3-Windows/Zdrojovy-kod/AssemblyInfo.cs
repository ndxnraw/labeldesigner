﻿using System.Reflection;
[assembly: AssemblyTitle("EAN Label Generator")]
[assembly: AssemblyDescription("Editor etikiet a ciarovych kodov pre Windows")]
[assembly: AssemblyVersion("2.3.0.0")]
[assembly: AssemblyFileVersion("2.3.0.0")]

[assembly: AssemblyProduct("EAN Label Generator")]
