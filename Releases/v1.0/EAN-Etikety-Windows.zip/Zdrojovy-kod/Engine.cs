﻿using System;
using System.IO;
using System.IO.Compression;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace EanEtikety {
public class TextItem {
 public string Text {get;set;}
 public double X {get;set;} public double Y {get;set;}
 public double Width {get;set;} public double Height {get;set;}
 public double Size {get;set;} public bool Bold {get;set;} public bool Center {get;set;}
 public TextItem(){Text="";Width=54;Height=6;Size=11;}
}
public class LabelSettings {
 public string Ean="8580000000016";
 public int Kind=13, Copies=1;
 public double Width=60, Height=45, Dpi=300;
 public double BarX=10, BarY=10, BarWidth=40, BarHeight=23.5, DigitSize=8;
 public bool Digits=true, Sheet=false;
 public double PageWidth=210, PageHeight=297, MarginX=10, MarginY=10, GapX=2, GapY=2;
 public List<TextItem> Texts=new List<TextItem>();
 public static LabelSettings Default(){var s=new LabelSettings();s.Texts.Add(new TextItem{Text="Názov produktu",X=3,Y=3,Bold=true});s.Texts.Add(new TextItem{Text="Cena: 12,90 €",X=3,Y=39,Size=10,Height=5});return s;}
}
public static class Engine {
 static readonly string[] L={"0001101","0011001","0010011","0111101","0100011","0110001","0101111","0111011","0110111","0001011"};
 static readonly string[] G={"0100111","0110011","0011011","0100001","0011101","0111001","0000101","0010001","0001001","0010111"};
 static readonly string[] Parity={"LLLLLL","LLGLGG","LLGGLG","LLGGGL","LGLLGG","LGGLLG","LGGGLL","LGLGLG","LGLGGL","LGGLGL"};
 public static string Normalize(string input,int kind){
  if(kind!=8&&kind!=13)throw new Exception("Vyberte EAN-8 alebo EAN-13.");
  string s=(input??"").Trim();
  if(s.Length!=kind&&s.Length!=kind-1)throw new Exception("EAN musí obsahovať "+(kind-1)+" číslic bez kontrolnej číslice alebo "+kind+" číslic s kontrolnou číslicou.");
  foreach(char c in s)if(c<'0'||c>'9')throw new Exception("EAN môže obsahovať iba číslice 0 až 9.");
  int sum=0,weight=3;for(int i=kind-2;i>=0;i--){sum+=(s[i]-'0')*weight;weight=4-weight;}
  char check=(char)('0'+(10-sum%10)%10);
  if(s.Length==kind-1)return s+check;
  if(s[kind-1]!=check)throw new Exception("Nesprávna kontrolná číslica. Správna posledná číslica je "+check+".");
  return s;
 }
 public static string Bits(string value,int kind){
  string s=Normalize(value,kind);var b=new StringBuilder("101");int half=kind==13?6:4,start=kind==13?1:0;
  for(int i=0;i<half;i++){int n=s[start+i]-'0';b.Append(kind==13&&Parity[s[0]-'0'][i]=='G'?G[n]:L[n]);}
  b.Append("01010");for(int i=start+half;i<kind;i++)foreach(char c in L[s[i]-'0'])b.Append(c=='0'?'1':'0');b.Append("101");return b.ToString();
 }
 static void Range(double n,double min,double max,string field){if(double.IsNaN(n)||double.IsInfinity(n)||n<min||n>max)throw new Exception(field+": povolený rozsah "+min+" až "+max+".");}
 public static void Validate(LabelSettings s){
  Normalize(s.Ean,s.Kind);Range(s.Width,10,500,"Šírka etikety");Range(s.Height,10,500,"Výška etikety");Range(s.Dpi,150,610,"Rozlíšenie");Range(s.Copies,1,500,"Počet kópií");
  Range(s.BarX,0,500,"Poloha EAN X");Range(s.BarY,0,500,"Poloha EAN Y");Range(s.BarWidth,1,500,"Šírka EAN");Range(s.BarHeight,1,500,"Výška čiar");Range(s.DigitSize,4,72,"Písmo EAN");
  double dh=s.Digits?s.DigitSize*25.4/72*1.5:0;
  if(s.BarX+s.BarWidth>s.Width+.001||s.BarY+s.BarHeight+dh>s.Height+.001)throw new Exception("EAN vrátane číslic presahuje etiketu. Upravte jeho polohu, rozmery alebo veľkosť číslic.");
  if(Module(s)<1)throw new Exception("EAN je pre zvolené rozlíšenie príliš úzky.");
  if(s.Width*s.Height*s.Dpi*s.Dpi/(25.4*25.4)>40000000)throw new Exception("Etiketa je pri tomto DPI príliš veľká. Znížte rozmery alebo DPI.");
  if(s.Texts==null||s.Texts.Count>50)throw new Exception("Povolených je najviac 50 textových polí.");
  foreach(var t in s.Texts){if(t==null||t.Text==null||t.Text.Length>4000)throw new Exception("Text je príliš dlhý.");Range(t.X,0,500,"Text X");Range(t.Y,0,500,"Text Y");Range(t.Width,1,500,"Šírka textového poľa");Range(t.Height,1,500,"Výška textového poľa");Range(t.Size,4,144,"Veľkosť písma");if(t.Text.Length>0&&(t.X+t.Width>s.Width+.001||t.Y+t.Height>s.Height+.001))throw new Exception("Textové pole presahuje etiketu: "+t.Text);}
  {Range(s.PageWidth,20,500,"Šírka papiera");Range(s.PageHeight,20,500,"Výška papiera");Range(s.MarginX,0,250,"Okraj X");Range(s.MarginY,0,250,"Okraj Y");Range(s.GapX,0,100,"Medzera X");Range(s.GapY,0,100,"Medzera Y");if(s.Sheet&&(Columns(s)<1||Rows(s)<1))throw new Exception("Na papier sa nezmestí ani jedna etiketa. Upravte rozmery alebo okraje.");}
 }
 public static int Modules(LabelSettings s){return s.Kind==13?113:81;}
 public static int Module(LabelSettings s){return (int)Math.Floor(s.BarWidth*s.Dpi/25.4/Modules(s)+1e-7);}
 public static int Columns(LabelSettings s){return s.Sheet?(int)Math.Floor((s.PageWidth-2*s.MarginX+s.GapX)/(s.Width+s.GapX)+1e-7):1;}
 public static int Rows(LabelSettings s){return s.Sheet?(int)Math.Floor((s.PageHeight-2*s.MarginY+s.GapY)/(s.Height+s.GapY)+1e-7):1;}
 public static List<string> Warnings(LabelSettings s){
  var w=new List<string>();double x=Module(s)*25.4/s.Dpi;
  if(x<.264)w.Add("Úzka čiara má iba "+x.ToString("0.000")+" mm. Zväčšite šírku EAN pre spoľahlivejšie čítanie.");
  if(s.BarHeight<(s.Kind==13?22.85:18.23)*x/.33)w.Add("Výška čiar je nízka vzhľadom na ich šírku. Pred použitím overte čitateľnosť skenerom.");
  var bar=new RectangleF((float)s.BarX,(float)s.BarY,(float)s.BarWidth,(float)(s.BarHeight+(s.Digits?s.DigitSize*25.4/72*1.5:0)));
  using(var bmp=new Bitmap(1,1))using(var g=Graphics.FromImage(bmp)){
   double k=s.Dpi/25.4;g.TextRenderingHint=TextRenderingHint.SingleBitPerPixelGridFit;
   foreach(var t in s.Texts){if(t.Text.Length==0)continue;
    if(bar.IntersectsWith(new RectangleF((float)t.X,(float)t.Y,(float)t.Width,(float)t.Height)))w.Add("Textové pole zasahuje do oblasti EAN: "+t.Text);
    using(var f=new Font("Arial",(float)(t.Size*s.Dpi/72),t.Bold?FontStyle.Bold:FontStyle.Regular,GraphicsUnit.Pixel))using(var fmt=TextFormat(t)){
     var z=g.MeasureString(t.Text,f,(int)Math.Max(1,t.Width*k),fmt);if(z.Height>t.Height*k+1)w.Add("Text sa nezmestí do výšky poľa: "+t.Text);
    }
   }
  }return w;
 }
 static StringFormat TextFormat(TextItem t){var f=new StringFormat(StringFormat.GenericTypographic);f.Alignment=t.Center?StringAlignment.Center:StringAlignment.Near;f.Trimming=StringTrimming.None;return f;}
 public static Bitmap Render(LabelSettings s){
  Validate(s);double k=s.Dpi/25.4;var bmp=new Bitmap((int)Math.Round(s.Width*k),(int)Math.Round(s.Height*k),PixelFormat.Format24bppRgb);bmp.SetResolution((float)s.Dpi,(float)s.Dpi);
  using(var g=Graphics.FromImage(bmp)){
   g.Clear(Color.White);g.TextRenderingHint=TextRenderingHint.SingleBitPerPixelGridFit;
   foreach(var t in s.Texts)using(var f=new Font("Arial",(float)(t.Size*s.Dpi/72),t.Bold?FontStyle.Bold:FontStyle.Regular,GraphicsUnit.Pixel))using(var fmt=TextFormat(t)){
    var r=new RectangleF((float)(t.X*k),(float)(t.Y*k),(float)(t.Width*k),(float)(t.Height*k));g.SetClip(r);g.DrawString(t.Text,f,Brushes.Black,r,fmt);g.ResetClip();
   }
   string bits=Bits(s.Ean,s.Kind),ean=Normalize(s.Ean,s.Kind);int m=Module(s),quiet=s.Kind==13?11:7;
   int x=(int)Math.Round(s.BarX*k)+(int)Math.Round((s.BarWidth*k-Modules(s)*m)/2),y=(int)Math.Round(s.BarY*k),h=(int)Math.Round(s.BarHeight*k);
   int guard=s.Digits?Math.Min(5*m,(int)(s.DigitSize*s.Dpi/72*.45)):0;
   for(int i=0;i<bits.Length;i++)if(bits[i]=='1'){bool special=i<3||i>=bits.Length-3||(i>=(s.Kind==13?45:31)&&i<(s.Kind==13?50:36));g.FillRectangle(Brushes.Black,x+(quiet+i)*m,y,m,h+(special?guard:0));}
   if(s.Digits)using(var f=new Font("Arial",(float)(s.DigitSize*s.Dpi/72),FontStyle.Regular,GraphicsUnit.Pixel))using(var fmt=new StringFormat(StringFormat.GenericTypographic)){
    fmt.Alignment=StringAlignment.Center;fmt.FormatFlags=StringFormatFlags.NoWrap;
    if(s.Kind==13){DrawDigits(g,ean.Substring(0,1),f,fmt,x,y+h,10*m);DrawDigits(g,ean.Substring(1,6),f,fmt,x+14*m,y+h,42*m);DrawDigits(g,ean.Substring(7,6),f,fmt,x+61*m,y+h,42*m);}
    else {DrawDigits(g,ean.Substring(0,4),f,fmt,x+10*m,y+h,28*m);DrawDigits(g,ean.Substring(4,4),f,fmt,x+43*m,y+h,28*m);}
   }
  }return bmp;
 }
 static void DrawDigits(Graphics g,string s,Font f,StringFormat fmt,int x,int y,int width){var size=g.MeasureString(s,f,int.MaxValue,fmt);if(size.Width>width+1)throw new Exception("Číslice pod EAN sú príliš veľké. Znížte veľkosť písma EAN alebo zväčšite jeho šírku.");g.DrawString(s,f,Brushes.Black,new RectangleF(x,y,width,f.GetHeight(g)*1.5f),fmt);}
 public static byte[] Packed(Bitmap bmp,bool blackOne){int stride=(bmp.Width+7)/8;var result=new byte[stride*bmp.Height];var bd=bmp.LockBits(new Rectangle(0,0,bmp.Width,bmp.Height),ImageLockMode.ReadOnly,PixelFormat.Format24bppRgb);try{var row=new byte[Math.Abs(bd.Stride)];for(int y=0;y<bmp.Height;y++){Marshal.Copy(IntPtr.Add(bd.Scan0,y*bd.Stride),row,0,row.Length);for(int x=0;x<bmp.Width;x++){bool black=(row[x*3]+row[x*3+1]+row[x*3+2])<384;if(black==blackOne)result[y*stride+x/8]|=(byte)(128>>(x%8));}}}finally{bmp.UnlockBits(bd);}return result;}
 public static void Zpl(string path,LabelSettings s){using(var b=Render(s)){var data=Packed(b,true);int stride=(b.Width+7)/8,stripRows=Math.Max(1,60000/stride);using(var w=new StreamWriter(path,false,Encoding.ASCII)){w.Write("^XA\n^PW"+b.Width+"\n^LL"+b.Height+"\n^LH0,0\n");for(int y=0;y<b.Height;y+=stripRows){int count=Math.Min(stripRows,b.Height-y)*stride;w.Write("^FO0,"+y+"^GFA,"+count+","+count+","+stride+",");for(int i=0;i<count;i++)w.Write(data[y*stride+i].ToString("X2"));w.Write("^FS\n");}w.Write("^PQ"+s.Copies+",0,1,N\n^XZ\n");}}}
 static string F(double x){return x.ToString("0.#####",CultureInfo.InvariantCulture);}
 static List<PointF> Positions(LabelSettings s,int page){var a=new List<PointF>();int cols=Columns(s),rows=Rows(s),cap=cols*rows,remaining=Math.Min(cap,s.Copies-page*cap);for(int i=0;i<remaining;i++)a.Add(new PointF((float)(s.Sheet?s.MarginX+(i%cols)*(s.Width+s.GapX):0),(float)(s.Sheet?s.MarginY+(i/cols)*(s.Height+s.GapY):0)));return a;}
 static byte[] Zlib(byte[] data){using(var outp=new MemoryStream()){outp.WriteByte(0x78);outp.WriteByte(0x9c);using(var zip=new DeflateStream(outp,CompressionLevel.Optimal,true))zip.Write(data,0,data.Length);uint a=1,b=0;foreach(byte v in data){a=(a+v)%65521;b=(b+a)%65521;}uint ad=(b<<16)|a;for(int shift=24;shift>=0;shift-=8)outp.WriteByte((byte)(ad>>shift));return outp.ToArray();}}
 static byte[] Bytes(string s){return Encoding.ASCII.GetBytes(s);}
 static byte[] StreamObj(string dict,byte[] data){using(var ms=new MemoryStream()){var begin=Bytes("<< "+dict+" /Length "+data.Length+" >>\nstream\n");ms.Write(begin,0,begin.Length);ms.Write(data,0,data.Length);var end=Bytes("\nendstream");ms.Write(end,0,end.Length);return ms.ToArray();}}
 public static void Pdf(string path,LabelSettings s){Validate(s);var objects=new List<byte[]>();int cap=Columns(s)*Rows(s),pages=(s.Copies+cap-1)/cap;objects.Add(Bytes("<< /Type /Catalog /Pages 2 0 R >>"));var kids=new StringBuilder();for(int p=0;p<pages;p++)kids.Append((4+p*2)+" 0 R ");objects.Add(Bytes("<< /Type /Pages /Count "+pages+" /Kids ["+kids+"] >>"));using(var b=Render(s)){objects.Add(StreamObj("/Type /XObject /Subtype /Image /Width "+b.Width+" /Height "+b.Height+" /ColorSpace /DeviceGray /BitsPerComponent 1 /Filter /FlateDecode",Zlib(Packed(b,false))));}
  double pw=(s.Sheet?s.PageWidth:s.Width)*72/25.4,ph=(s.Sheet?s.PageHeight:s.Height)*72/25.4;
  for(int p=0;p<pages;p++){objects.Add(Bytes("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 "+F(pw)+" "+F(ph)+"] /Resources << /XObject << /Im1 3 0 R >> >> /Contents "+(5+p*2)+" 0 R >>"));var content=new StringBuilder();foreach(var pos in Positions(s,p))content.Append("q "+F(s.Width*72/25.4)+" 0 0 "+F(s.Height*72/25.4)+" "+F(pos.X*72/25.4)+" "+F(ph-(pos.Y+s.Height)*72/25.4)+" cm /Im1 Do Q\n");objects.Add(StreamObj("",Bytes(content.ToString())));}
  using(var fs=File.Create(path)){Action<byte[]> write=delegate(byte[] d){fs.Write(d,0,d.Length);};write(Bytes("%PDF-1.4\n"));var offsets=new List<long>();for(int i=0;i<objects.Count;i++){offsets.Add(fs.Position);write(Bytes((i+1)+" 0 obj\n"));write(objects[i]);write(Bytes("\nendobj\n"));}long xref=fs.Position;write(Bytes("xref\n0 "+(objects.Count+1)+"\n0000000000 65535 f \n"));foreach(long offset in offsets)write(Bytes(offset.ToString("D10")+" 00000 n \n"));write(Bytes("trailer\n<< /Size "+(objects.Count+1)+" /Root 1 0 R >>\nstartxref\n"+xref+"\n%%EOF\n"));}
 }
 static void ZipText(ZipArchive z,string name,string txt){using(var w=new StreamWriter(z.CreateEntry(name).Open(),new UTF8Encoding(false)))w.Write(txt);}
 public static void Docx(string path,LabelSettings s){Validate(s);int cap=Columns(s)*Rows(s),pages=(s.Copies+cap-1)/cap;long cx=(long)Math.Round(s.Width*36000),cy=(long)Math.Round(s.Height*36000);var body=new StringBuilder();int id=0;
  for(int page=0;page<pages;page++){body.Append("<w:p><w:pPr>"+(page>0?"<w:pageBreakBefore/>":"")+"<w:spacing w:before=\"0\" w:after=\"0\" w:line=\"1\" w:lineRule=\"exact\"/></w:pPr>");foreach(var pos in Positions(s,page)){id++;body.Append("<w:r><w:drawing><wp:anchor distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\" simplePos=\"0\" relativeHeight=\"0\" behindDoc=\"0\" locked=\"0\" layoutInCell=\"1\" allowOverlap=\"1\"><wp:simplePos x=\"0\" y=\"0\"/><wp:positionH relativeFrom=\"page\"><wp:posOffset>"+Math.Round(pos.X*36000)+"</wp:posOffset></wp:positionH><wp:positionV relativeFrom=\"page\"><wp:posOffset>"+Math.Round(pos.Y*36000)+"</wp:posOffset></wp:positionV><wp:extent cx=\""+cx+"\" cy=\""+cy+"\"/><wp:wrapNone/><wp:docPr id=\""+id+"\" name=\"Etiketa "+id+"\" descr=\"EAN etiketa\"/><wp:cNvGraphicFramePr/><a:graphic><a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\"><pic:pic><pic:nvPicPr><pic:cNvPr id=\"0\" name=\"Etiketa\"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed=\"rId1\"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\""+cx+"\" cy=\""+cy+"\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:anchor></w:drawing></w:r>");}body.Append("</w:p>");}
  body.Append("<w:sectPr><w:pgSz w:w=\""+Math.Round((s.Sheet?s.PageWidth:s.Width)*1440/25.4)+"\" w:h=\""+Math.Round((s.Sheet?s.PageHeight:s.Height)*1440/25.4)+"\"/><w:pgMar w:top=\"0\" w:right=\"0\" w:bottom=\"0\" w:left=\"0\" w:header=\"0\" w:footer=\"0\" w:gutter=\"0\"/></w:sectPr>");
  using(var fs=File.Create(path))using(var z=new ZipArchive(fs,ZipArchiveMode.Create)){
   ZipText(z,"[Content_Types].xml","<?xml version=\"1.0\" encoding=\"utf-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Default Extension=\"png\" ContentType=\"image/png\"/><Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>");
   ZipText(z,"_rels/.rels","<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>");
   ZipText(z,"word/_rels/document.xml.rels","<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"media/label.png\"/></Relationships>");
   ZipText(z,"word/document.xml","<?xml version=\"1.0\" encoding=\"utf-8\"?><w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><w:body>"+body+"</w:body></w:document>");
   using(var b=Render(s))using(var stream=z.CreateEntry("word/media/label.png").Open())b.Save(stream,ImageFormat.Png);
  }
 }
 public static void Save(string file,LabelSettings s){using(var w=XmlWriter.Create(file,new XmlWriterSettings{Indent=true,Encoding=new UTF8Encoding(false)}))new XmlSerializer(typeof(LabelSettings)).Serialize(w,s);}
 public static LabelSettings Load(string file){using(var r=XmlReader.Create(file,new XmlReaderSettings{DtdProcessing=DtdProcessing.Prohibit,XmlResolver=null,MaxCharactersInDocument=1000000})){var s=(LabelSettings)new XmlSerializer(typeof(LabelSettings)).Deserialize(r);Validate(s);return s;}}
}
}


