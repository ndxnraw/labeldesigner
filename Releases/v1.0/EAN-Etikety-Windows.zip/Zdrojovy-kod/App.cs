﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace EanEtikety {
public class PreviewPanel:Panel {
 public Bitmap Image;public string Caption="";
 public PreviewPanel(){DoubleBuffered=true;BackColor=Color.FromArgb(232,237,244);}
 protected override void OnPaint(PaintEventArgs e){base.OnPaint(e);var g=e.Graphics;g.TextRenderingHint=System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
  using(var f=new Font("Segoe UI",11,FontStyle.Bold))g.DrawString("NÁHĽAD ETIKETY",f,Brushes.DimGray,24,20);
  if(Image==null){g.DrawString("Upravte údaje podľa hlásenia nižšie.",Font,Brushes.DimGray,24,65);return;}
  float scale=Math.Min((ClientSize.Width-80f)/Image.Width,(ClientSize.Height-120f)/Image.Height);if(scale<=0)return;
  int w=(int)(Image.Width*scale),h=(int)(Image.Height*scale),x=(Width-w)/2,y=60+(Height-120-h)/2;
  using(var shadow=new SolidBrush(Color.FromArgb(205,214,226)))g.FillRectangle(shadow,x+6,y+6,w,h);
  g.InterpolationMode=InterpolationMode.NearestNeighbor;g.PixelOffsetMode=PixelOffsetMode.Half;g.DrawImage(Image,new Rectangle(x,y,w,h));g.DrawRectangle(Pens.SlateGray,x-1,y-1,w+1,h+1);
  using(var f=new Font("Segoe UI",10))using(var fmt=new StringFormat{Alignment=StringAlignment.Center})g.DrawString(Caption,f,Brushes.DimGray,new RectangleF(10,Height-40,Width-20,30),fmt);
 }
 protected override void Dispose(bool disposing){if(disposing&&Image!=null)Image.Dispose();base.Dispose(disposing);}
}
public class MainForm:Form {
 Dictionary<string,NumericUpDown> nums=new Dictionary<string,NumericUpDown>();
 TextBox ean=new TextBox();ComboBox kind=new ComboBox(),dpi=new ComboBox();CheckBox digits=new CheckBox(),sheet=new CheckBox();
 DataGridView grid=new DataGridView();PreviewPanel preview=new PreviewPanel();Label status=new Label();Timer timer=new Timer();
 bool loading=false,dirty=false;string settingsPath=null;Button pdf,docx,zpl;
 public MainForm(){
  Text="EAN Etikety";Font=new Font("Segoe UI",10);Size=new Size(1320,930);MinimumSize=new Size(1000,740);StartPosition=FormStartPosition.CenterScreen;BackColor=Color.White;AutoScaleMode=AutoScaleMode.Dpi;
  var root=new TableLayoutPanel{Dock=DockStyle.Fill,RowCount=4,ColumnCount=1,Padding=new Padding(14)};root.RowStyles.Add(new RowStyle(SizeType.Absolute,58));root.RowStyles.Add(new RowStyle(SizeType.Percent,62));root.RowStyles.Add(new RowStyle(SizeType.Percent,38));root.RowStyles.Add(new RowStyle(SizeType.Absolute,82));Controls.Add(root);
  var toolbar=new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=false,AutoScroll=true};root.Controls.Add(toolbar,0,0);
  toolbar.Controls.Add(new Label{Text="EAN Etikety",Font=new Font("Segoe UI",17,FontStyle.Bold),AutoSize=true,Margin=new Padding(0,5,22,0)});
  toolbar.Controls.Add(Btn("Otvoriť",Open));toolbar.Controls.Add(Btn("Uložiť",Save));toolbar.Controls.Add(Btn("Uložiť ako",SaveAs));
  pdf=Btn("Export PDF",delegate{Export("pdf");});docx=Btn("Export Word",delegate{Export("docx");});zpl=Btn("Export ZPL",delegate{Export("zpl");});
  foreach(var b in new[]{pdf,docx,zpl}){b.BackColor=Color.FromArgb(28,73,153);b.ForeColor=Color.White;toolbar.Controls.Add(b);}toolbar.Controls.Add(Btn("Návod",Help));
  var upper=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=2,RowCount=1};upper.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,440));upper.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));root.Controls.Add(upper,0,1);
  var tabs=new TabControl{Dock=DockStyle.Fill,Margin=new Padding(0,0,12,0)};upper.Controls.Add(tabs,0,0);upper.Controls.Add(preview,1,0);preview.Dock=DockStyle.Fill;
  var basic=Tab(tabs,"Etiketa a EAN");var page=Tab(tabs,"Papier a kópie");
  AddNum(basic,"Šírka etikety (mm)","Width",10,500,60);AddNum(basic,"Výška etikety (mm)","Height",10,500,45);
  kind.DropDownStyle=ComboBoxStyle.DropDownList;kind.Items.AddRange(new object[]{"EAN-13","EAN-8"});AddRow(basic,"Typ kódu",kind);kind.SelectedIndexChanged+=Changed;
  ean.MaxLength=13;AddRow(basic,"EAN (ručne)",ean);ean.TextChanged+=Changed;
  AddNum(basic,"Poloha EAN X (mm)","BarX",0,500,4);AddNum(basic,"Poloha EAN Y (mm)","BarY",0,500,12);
  AddNum(basic,"Šírka EAN s okrajmi (mm)","BarWidth",1,500,50);AddNum(basic,"Výška čiar (mm)","BarHeight",1,500,22);
  digits.Text="Zobraziť číslice";digits.AutoSize=true;AddRow(basic,"Číslice",digits);digits.CheckedChanged+=Changed;AddNum(basic,"Veľkosť číslic (pt)","DigitSize",4,72,10);
  dpi.DropDownStyle=ComboBoxStyle.DropDownList;dpi.Items.AddRange(new object[]{"203 DPI","203,2 DPI (8 bodov/mm)","300 DPI","304,8 DPI (12 bodov/mm)","600 DPI","609,6 DPI (24 bodov/mm)"});AddRow(basic,"Rozlíšenie tlačiarne",dpi);dpi.SelectedIndexChanged+=Changed;
  AddNum(page,"Počet rovnakých etikiet","Copies",1,500,1);nums["Copies"].DecimalPlaces=0;
  sheet.Text="Viac etikiet na jednom hárku";sheet.AutoSize=true;AddRow(page,"Word a PDF",sheet);sheet.CheckedChanged+=Changed;
  AddNum(page,"Šírka papiera (mm)","PageWidth",20,500,210);AddNum(page,"Výška papiera (mm)","PageHeight",20,500,297);
  AddNum(page,"Ľavý / pravý okraj (mm)","MarginX",0,250,10);AddNum(page,"Horný / dolný okraj (mm)","MarginY",0,250,10);
  AddNum(page,"Vodorovná medzera (mm)","GapX",0,100,2);AddNum(page,"Zvislá medzera (mm)","GapY",0,100,2);
  var info=new Label{AutoSize=true,MaximumSize=new Size(375,0),Text="Bez režimu hárku je každá etiketa samostatnou stranou. ZPL vždy vytvorí jednotlivé etikety na kotúči.\r\n\r\nPozície X a Y sa merajú od ľavého horného rohu etikety. Rozmery sú v mm, veľkosti písma v bodoch (pt).",Margin=new Padding(8,20,8,8)};page.Controls.Add(info);page.SetColumnSpan(info,2);
  var texts=new TableLayoutPanel{Dock=DockStyle.Fill,RowCount=2,ColumnCount=1,Margin=new Padding(0,14,0,0)};texts.RowStyles.Add(new RowStyle(SizeType.Absolute,44));texts.RowStyles.Add(new RowStyle(SizeType.Percent,100));root.Controls.Add(texts,0,2);
  var textTools=new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=false};textTools.Controls.Add(new Label{Text="Textové polia",Font=new Font("Segoe UI",12,FontStyle.Bold),AutoSize=true,Margin=new Padding(0,8,18,0)});textTools.Controls.Add(Btn("Pridať text",AddText));textTools.Controls.Add(Btn("Odstrániť riadok",RemoveText));textTools.Controls.Add(new Label{Text="Dvojklikom upravíte bunku. Text sa zalamuje podľa šírky poľa.",AutoSize=true,Margin=new Padding(14,10,0,0)});texts.Controls.Add(textTools,0,0);
  grid.Dock=DockStyle.Fill;grid.BackgroundColor=Color.White;grid.BorderStyle=BorderStyle.FixedSingle;grid.AllowUserToAddRows=false;grid.AllowUserToDeleteRows=false;grid.RowHeadersWidth=28;grid.SelectionMode=DataGridViewSelectionMode.CellSelect;grid.AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill;grid.RowTemplate.Height=34;grid.ColumnHeadersHeight=38;grid.ColumnHeadersHeightSizeMode=DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
  string[] cols={"Text","X (mm)","Y (mm)","Šírka (mm)","Výška (mm)","Písmo (pt)"};for(int i=0;i<cols.Length;i++){var col=new DataGridViewTextBoxColumn{Name="c"+i,HeaderText=cols[i],FillWeight=i==0?330:90,SortMode=DataGridViewColumnSortMode.NotSortable};grid.Columns.Add(col);}grid.Columns.Add(new DataGridViewCheckBoxColumn{Name="bold",HeaderText="Tučné",FillWeight=65});grid.Columns.Add(new DataGridViewCheckBoxColumn{Name="center",HeaderText="Na stred",FillWeight=75});texts.Controls.Add(grid,0,1);
  grid.CellValueChanged+=Changed;grid.RowsRemoved+=Changed;grid.CurrentCellDirtyStateChanged+=delegate{if(grid.IsCurrentCellDirty&&grid.CurrentCell is DataGridViewCheckBoxCell)grid.CommitEdit(DataGridViewDataErrorContexts.Commit);};grid.DataError+=delegate(object sender,DataGridViewDataErrorEventArgs a){a.ThrowException=false;status.Text="Skontrolujte hodnotu v textovej tabuľke.";};
  status.Dock=DockStyle.Fill;status.Padding=new Padding(4,10,0,0);status.AutoEllipsis=true;root.Controls.Add(status,0,3);
  timer.Interval=300;timer.Tick+=delegate{timer.Stop();UpdatePreview();};Apply(LabelSettings.Default());FormClosing+=delegate(object sender,FormClosingEventArgs args){if(!CanDiscard())args.Cancel=true;};
 }
 Button Btn(string text,Action action){var b=new Button{Text=text,AutoSize=true,Height=36,Padding=new Padding(8,2,8,2),FlatStyle=FlatStyle.Flat,Margin=new Padding(0,4,8,2)};b.FlatAppearance.BorderColor=Color.LightSteelBlue;b.Click+=delegate{action();};return b;}
 TableLayoutPanel Tab(TabControl parent,string name){var tab=new TabPage(name){BackColor=Color.White,AutoScroll=true};parent.TabPages.Add(tab);var layout=new TableLayoutPanel{AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Dock=DockStyle.Top,ColumnCount=2,Padding=new Padding(7)};layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,57));layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,43));tab.Controls.Add(layout);return layout;}
 void AddRow(TableLayoutPanel p,string title,Control c){int r=p.RowCount++;p.RowStyles.Add(new RowStyle(SizeType.AutoSize));p.Controls.Add(new Label{Text=title,AutoSize=true,Anchor=AnchorStyles.Left,Margin=new Padding(3,9,3,9)},0,r);c.Dock=DockStyle.Fill;c.Margin=new Padding(3,5,3,5);p.Controls.Add(c,1,r);}
 void AddNum(TableLayoutPanel p,string title,string key,decimal min,decimal max,decimal val){var n=new NumericUpDown{Minimum=min,Maximum=max,Value=val,DecimalPlaces=2,Increment=.5m};nums.Add(key,n);AddRow(p,title,n);n.ValueChanged+=Changed;}
 void Changed(object sender,EventArgs args){if(loading)return;dirty=true;Text="EAN Etikety • neuložené zmeny";timer.Stop();timer.Start();}
 double N(string key){return (double)nums[key].Value;}
 static readonly double[] Dpis={203,203.2,300,304.8,600,609.6};
 LabelSettings Read(){grid.EndEdit();var s=new LabelSettings{Ean=ean.Text,Kind=kind.SelectedIndex==1?8:13,Digits=digits.Checked,Sheet=sheet.Checked,Dpi=Dpis[Math.Max(0,dpi.SelectedIndex)]};foreach(var pair in nums){var field=typeof(LabelSettings).GetField(pair.Key);if(field.FieldType==typeof(int))field.SetValue(s,(int)pair.Value.Value);else field.SetValue(s,(double)pair.Value.Value);}
  s.Texts.Clear();foreach(DataGridViewRow row in grid.Rows){var t=new TextItem();t.Text=Convert.ToString(row.Cells[0].Value)??"";double[] values=new double[5];for(int i=0;i<5;i++)if(!double.TryParse(Convert.ToString(row.Cells[i+1].Value),out values[i]))throw new Exception("Riadok "+(row.Index+1)+": zadajte číselnú hodnotu pre "+grid.Columns[i+1].HeaderText+".");t.X=values[0];t.Y=values[1];t.Width=values[2];t.Height=values[3];t.Size=values[4];t.Bold=Convert.ToBoolean(row.Cells[6].Value??false);t.Center=Convert.ToBoolean(row.Cells[7].Value??false);s.Texts.Add(t);}return s;
 }
 void Apply(LabelSettings s){loading=true;try{ean.Text=s.Ean;kind.SelectedIndex=s.Kind==8?1:0;digits.Checked=s.Digits;sheet.Checked=s.Sheet;int di=Array.IndexOf(Dpis,s.Dpi);if(di<0)throw new Exception("Súbor obsahuje nepodporované DPI.");dpi.SelectedIndex=di;foreach(var pair in nums)pair.Value.Value=Convert.ToDecimal(typeof(LabelSettings).GetField(pair.Key).GetValue(s));grid.Rows.Clear();foreach(var t in s.Texts)grid.Rows.Add(t.Text,t.X,t.Y,t.Width,t.Height,t.Size,t.Bold,t.Center);}finally{loading=false;}dirty=false;Text="EAN Etikety";UpdatePreview();}
 void UpdatePreview(){try{var s=Read();var bmp=Engine.Render(s);if(preview.Image!=null)preview.Image.Dispose();preview.Image=bmp;preview.Caption=s.Width+" × "+s.Height+" mm  |  "+s.Dpi+" DPI  |  "+Engine.Normalize(s.Ean,s.Kind);var warnings=Engine.Warnings(s);double real=Engine.Module(s)*Engine.Modules(s)*25.4/s.Dpi;int cap=Engine.Columns(s)*Engine.Rows(s);status.Text="EAN: "+Engine.Normalize(s.Ean,s.Kind)+"  •  Šírka kódu po zarovnaní na body: "+real.ToString("0.00")+" mm  •  "+((s.Copies+cap-1)/cap)+" strana/strán"+(s.Sheet?"  •  "+Engine.Columns(s)+" × "+Engine.Rows(s)+" etikiet na hárku":"")+"\r\n"+(warnings.Count>0?string.Join("  ",warnings.ToArray()):"Pripravené na export. Pri tlači použite skutočnú veľkosť (100 %).");status.ForeColor=warnings.Count>0?Color.FromArgb(148,86,0):Color.FromArgb(32,84,58);pdf.Enabled=docx.Enabled=zpl.Enabled=true;}catch(Exception ex){if(preview.Image!=null){preview.Image.Dispose();preview.Image=null;}status.Text=ex.Message;status.ForeColor=Color.Firebrick;pdf.Enabled=docx.Enabled=zpl.Enabled=false;}preview.Invalidate();}
 void AddText(){if(grid.Rows.Count>=50)return;grid.Rows.Add("Nový text",3,3,Math.Max(1,N("Width")-6),6,10,false,false);Changed(this,EventArgs.Empty);}
 void RemoveText(){if(grid.CurrentCell!=null){grid.Rows.RemoveAt(grid.CurrentCell.RowIndex);Changed(this,EventArgs.Empty);}}
 bool CanDiscard(){if(!dirty)return true;var r=MessageBox.Show(this,"Chcete uložiť aktuálne nastavenie etikety?","Neuložené nastavenie",MessageBoxButtons.YesNoCancel,MessageBoxIcon.Question);if(r==DialogResult.Cancel)return false;if(r==DialogResult.Yes){Save();return !dirty;}return true;}
 void Open(){if(!CanDiscard())return;using(var d=new OpenFileDialog{Filter="Nastavenie etikety (*.ean.xml)|*.ean.xml|XML (*.xml)|*.xml"})if(d.ShowDialog(this)==DialogResult.OK)try{var s=Engine.Load(d.FileName);if(Array.IndexOf(Dpis,s.Dpi)<0)throw new Exception("Nepodporované DPI v súbore.");Apply(s);settingsPath=d.FileName;}catch(Exception ex){Error(ex);}}
 void Save(){if(settingsPath==null){SaveAs();return;}try{var s=Read();Engine.Validate(s);Atomic(settingsPath,delegate(string p){Engine.Save(p,s);});dirty=false;Text="EAN Etikety";status.Text="Nastavenie uložené: "+settingsPath;}catch(Exception ex){Error(ex);}}
 void SaveAs(){using(var d=new SaveFileDialog{Filter="Nastavenie etikety (*.ean.xml)|*.ean.xml",FileName="Moja etiketa.ean.xml"})if(d.ShowDialog(this)==DialogResult.OK){string previous=settingsPath;settingsPath=d.FileName;Save();if(dirty)settingsPath=previous;}}
 static void Atomic(string target,Action<string> action){string tmp=target+"."+Guid.NewGuid().ToString("N")+".tmp";try{action(tmp);if(File.Exists(target))File.Replace(tmp,target,null);else File.Move(tmp,target);}finally{if(File.Exists(tmp))File.Delete(tmp);}}
 void Export(string format){try{var s=Read();Engine.Validate(s);var warnings=Engine.Warnings(s);if(warnings.Count>0&&MessageBox.Show(this,string.Join("\r\n",warnings.ToArray())+"\r\n\r\nPokračovať v exporte?","Kontrola etikety",MessageBoxButtons.YesNo,MessageBoxIcon.Warning)!=DialogResult.Yes)return;using(var d=new SaveFileDialog{Filter=format.ToUpper()+" (*."+format+")|*."+format,FileName="Etikety-"+Engine.Normalize(s.Ean,s.Kind)+"."+format})if(d.ShowDialog(this)==DialogResult.OK){UseWaitCursor=true;try{Atomic(d.FileName,delegate(string p){if(format=="pdf")Engine.Pdf(p,s);else if(format=="docx")Engine.Docx(p,s);else Engine.Zpl(p,s);});status.Text="Export uložený: "+d.FileName;status.ForeColor=Color.FromArgb(32,84,58);}finally{UseWaitCursor=false;}}}catch(Exception ex){Error(ex);}}
 void Error(Exception e){MessageBox.Show(this,e.Message,"EAN Etikety",MessageBoxButtons.OK,MessageBoxIcon.Error);}
 void Help(){MessageBox.Show(this,"1. Zadajte EAN-13 (12 alebo 13 číslic) alebo EAN-8 (7 alebo 8 číslic). Kontrolná číslica sa doplní pri neúplnom kóde.\r\n2. Nastavte rozmery etikety, polohu a rozmery EAN. Šírka zahŕňa voľné okraje.\r\n3. V tabuľke pridajte a upravte texty, ich polohu, rozmery a písmo.\r\n4. Na karte Papier a kópie nastavte počet a rozloženie na hárok.\r\n5. Exportujte PDF, Word (.docx) alebo ZPL.\r\n\r\nWord obsahuje etikety ako obrázky s presnou veľkosťou. Text upravujte v tomto programe. ZPL používa čiernobielu grafiku vrátane diakritiky; DPI musí zodpovedať tlačiarni.\r\n\r\nNastavenie uložte do súboru .ean.xml. Tlačte v mierke 100 %. Program kontroluje číslice EAN, neprideľuje registračné čísla GS1.","Ako používať program",MessageBoxButtons.OK,MessageBoxIcon.Information);}
 public void CapturePreview(string path){Size=new Size(1320,930);Show();Application.DoEvents();using(var b=new Bitmap(Width,Height)){DrawToBitmap(b,new Rectangle(0,0,Width,Height));b.Save(path);}dirty=false;Close();}
}
public static class Program {
 [STAThread]public static void Main(string[] args){Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);if(args.Length==2&&args[0]=="--self-test"){try{SelfTest(args[1]);Environment.ExitCode=0;}catch(Exception ex){Directory.CreateDirectory(args[1]);File.WriteAllText(Path.Combine(args[1],"failure.txt"),ex.ToString());Environment.ExitCode=1;}return;}Application.Run(new MainForm());}
 static void Assert(bool val,string what){if(!val)throw new Exception("Test zlyhal: "+what);}
 static void Reject(Action a,string what){bool rejected=false;try{a();}catch{rejected=true;}Assert(rejected,what);}
 static void SelfTest(string folder){Directory.CreateDirectory(folder);Assert(Engine.Normalize("400638133393",13)=="4006381333931","EAN13 checksum");Assert(Engine.Normalize("9638507",8)=="96385074","EAN8 checksum");Assert(Engine.Normalize("000000000000",13)=="0000000000000","leading zeros");Reject(delegate{Engine.Normalize("4006381333932",13);},"wrong checksum");Reject(delegate{Engine.Normalize("123A567",8);},"letters");Reject(delegate{Engine.Normalize("１２３４５６７",8);},"unicode digits");Assert(Engine.Bits("4006381333931",13).Length==95,"95 modules");Assert(Engine.Bits("96385074",8).Length==67,"67 modules");var s=LabelSettings.Default();Assert(Engine.Normalize(s.Ean,13)==s.Ean,"default valid");
  foreach(int k in new[]{13,8}){s.Kind=k;s.Ean=k==13?"4006381333931":"96385074";using(var b=Engine.Render(s))b.Save(Path.Combine(folder,"ean"+k+".png"));Engine.Pdf(Path.Combine(folder,"ean"+k+".pdf"),s);Engine.Docx(Path.Combine(folder,"ean"+k+".docx"),s);Engine.Zpl(Path.Combine(folder,"ean"+k+".zpl"),s);}
  s.Kind=13;s.Ean="4006381333931";s.Sheet=true;s.Copies=25;Assert(Engine.Columns(s)==3&&Engine.Rows(s)==5,"A4 grid");Engine.Pdf(Path.Combine(folder,"sheet.pdf"),s);Engine.Docx(Path.Combine(folder,"sheet.docx"),s);Engine.Save(Path.Combine(folder,"settings.ean.xml"),s);Assert(Engine.Load(Path.Combine(folder,"settings.ean.xml")).Copies==25,"settings roundtrip");s.Width=10;Reject(delegate{Engine.Validate(s);},"overflow");s=LabelSettings.Default();s.Dpi=203.2;Engine.Zpl(Path.Combine(folder,"203dpi.zpl"),s);using(var b=Engine.Render(s)){Assert(b.Width==480&&b.Height==360,"8dots per mm");}
  s=LabelSettings.Default();s.Width=210;s.Height=100;s.Dpi=600;Engine.Zpl(Path.Combine(folder,"large.zpl"),s);using(var b=Engine.Render(s))b.Save(Path.Combine(folder,"large.png"));
  using(var form=new MainForm())form.CapturePreview(Path.Combine(folder,"app.png"));File.WriteAllText(Path.Combine(folder,"passed.txt"),"EAN checksum, leading zeros, invalid data, module lengths, label boundaries, A4 pagination, XML roundtrip, PDF/DOCX/ZPL generation and UI rendering passed.");
 }
}
}

