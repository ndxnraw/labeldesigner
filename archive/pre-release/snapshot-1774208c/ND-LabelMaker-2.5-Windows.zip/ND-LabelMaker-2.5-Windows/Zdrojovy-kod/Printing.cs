using System;using System.Drawing;using System.Drawing.Printing;using System.Windows.Forms;
namespace EanEtikety {
public class LabelPrintDocument:PrintDocument {
 readonly LabelSettings label;readonly VectorScene scene;int page;
 public int PageCount {get{return (label.Copies+Capacity-1)/Capacity;}}
 public int Capacity {get{return Engine.Columns(label)*Engine.Rows(label);}}
 public double WidthMm {get{return label.Sheet?label.PageWidth:label.Width;}}
 public double HeightMm {get{return label.Sheet?label.PageHeight:label.Height;}}
 public LabelPrintDocument(LabelSettings settings){Engine.Validate(settings);label=settings;scene=VectorArt.Build(settings);DocumentName="ND LabelMaker";OriginAtMargins=true;
  DefaultPageSettings.Margins=new Margins(0,0,0,0);DefaultPageSettings.Landscape=false;
  DefaultPageSettings.PaperSize=new PaperSize("ND LabelMaker",(int)Math.Round(WidthMm/25.4*100),(int)Math.Round(HeightMm/25.4*100));PrinterSettings.Copies=1;
 }
 public RectangleF LabelBounds(int index){int cols=Engine.Columns(label);return new RectangleF((float)(label.Sheet?label.MarginX+(index%cols)*(label.Width+label.GapX):0),(float)(label.Sheet?label.MarginY+(index/cols)*(label.Height+label.GapY):0),(float)label.Width,(float)label.Height);}
 public int RenderPage(Graphics g,int pageIndex){if(pageIndex<0||pageIndex>=PageCount)throw new ArgumentOutOfRangeException("pageIndex");var saved=g.Save();try{g.PageUnit=GraphicsUnit.Millimeter;g.PageScale=1;int count=Math.Min(Capacity,label.Copies-pageIndex*Capacity);for(int i=0;i<count;i++)scene.Draw(g,LabelBounds(i),false);return count;}finally{g.Restore(saved);}}
 public bool FitsPaper(Rectangle bounds){return bounds.Width*25.4/100+.5>=WidthMm&&bounds.Height*25.4/100+.5>=HeightMm;}
 public bool ContentFits(RectangleF printable){var area=new RectangleF(printable.X*.254f,printable.Y*.254f,printable.Width*.254f,printable.Height*.254f);area.Inflate(.15f,.15f);for(int i=0;i<Math.Min(Capacity,label.Copies);i++){var pos=LabelBounds(i);foreach(var shape in scene.Shapes){var b=RectangleF.Intersect(shape.Path.GetBounds(),shape.Clip);b=RectangleF.Intersect(b,new RectangleF(0,0,(float)label.Width,(float)label.Height));if(b.IsEmpty)continue;b.Offset(pos.X,pos.Y);if(!area.Contains(b))return false;}}return true;}
 protected override void OnBeginPrint(PrintEventArgs e){page=0;base.OnBeginPrint(e);}
 protected override void OnPrintPage(PrintPageEventArgs e){if(!FitsPaper(e.PageBounds))throw new InvalidOperationException(Loc.T("Papier tlačiarne je menší než nastavený formát. Upravte formát v nastavení tlačiarne."));RenderPage(e.Graphics,page++);e.HasMorePages=page<PageCount;base.OnPrintPage(e);}
 protected override void Dispose(bool disposing){if(disposing)scene.Dispose();base.Dispose(disposing);}
}
public partial class MainForm {
 void PrintLabel(){try{var s=Read();Engine.Validate(s);if(PrinterSettings.InstalledPrinters.Count==0)throw new InvalidOperationException(Loc.T("Vo Windows nie je nainštalovaná tlačiareň."));
  using(var document=new LabelPrintDocument(s))using(var dialog=new PrintDialog{Document=document,UseEXDialog=true,AllowSomePages=false,AllowSelection=false,AllowCurrentPage=false,AllowPrintToFile=false}){
   if(dialog.ShowDialog(this)!=DialogResult.OK)return;
   if(!document.PrinterSettings.IsValid)throw new InvalidOperationException(Loc.T("Vybraná tlačiareň nie je dostupná."));
   document.DefaultPageSettings.Margins=new Margins(0,0,0,0);
   if(!document.FitsPaper(document.DefaultPageSettings.Bounds))throw new InvalidOperationException(Loc.T("Papier tlačiarne je menší než nastavený formát. Upravte formát v nastavení tlačiarne."));
   var warnings=Engine.Warnings(s);if(!document.ContentFits(document.DefaultPageSettings.PrintableArea))warnings.Add(Loc.T("Časť obsahu je mimo tlačiteľnej oblasti tlačiarne a môže byť orezaná."));
   if(warnings.Count>0&&MessageBox.Show(this,string.Join("\r\n",warnings.ToArray())+"\r\n\r\n"+Loc.T("Pokračovať v tlači?"),Loc.T("Tlač"),MessageBoxButtons.YesNo,MessageBoxIcon.Warning)!=DialogResult.Yes)return;
   UseWaitCursor=true;try{document.Print();status.Text=Loc.T("Úloha bola odoslaná do tlačového systému Windows.");}finally{UseWaitCursor=false;}
  }
 }catch(Exception ex){Error(ex);}}
}
}
