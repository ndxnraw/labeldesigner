﻿using System;
using System.IO;
using System.Drawing;
using System.Windows.Forms;
namespace EanEtikety {
public partial class MainForm {
 void OpenImportedFile(string path){string extension=Path.GetExtension(path).ToLowerInvariant();
  if(extension!=".xml"&&extension!=".zpl"&&extension!=".prn")throw new NotSupportedException(Loc.T("Nepodporovaný typ súboru. Otvorte projekt XML alebo súbor ZPL/PRN."));
  if((extension==".zpl"||extension==".prn")){string source=ZplImport.ReadFile(path);var project=ZplImport.Project(source);if(project!=null){if(Array.IndexOf(Dpis,project.Dpi)<0)throw new Exception(Loc.T("Nepodporované DPI projektu v ZPL."));Apply(project);settingsPath=null;Changed(this,EventArgs.Empty);status.Text=Loc.T("ZPL/PRN bol otvorený ako editovateľná etiketa. Uložiť vytvorí nový súbor .ean.xml.");}else ShowZpl(path,source);return;}
  var s=Engine.Load(path);if(Array.IndexOf(Dpis,s.Dpi)<0)throw new Exception(Loc.T("Nepodporované DPI v súbore."));Apply(s);settingsPath=path;UpdateWindowTitle();
 }
 void ShowZpl(string path,string source){using(var dialog=new Form{Text="ZPL – "+Path.GetFileName(path),Size=new Size(1100,820),MinimumSize=new Size(780,600),Font=Font,StartPosition=FormStartPosition.CenterParent,MinimizeBox=false,ShowInTaskbar=false}){
  var root=new TableLayoutPanel{Dock=DockStyle.Fill,Padding=new Padding(14),RowCount=3,ColumnCount=1};root.RowStyles.Add(new RowStyle(SizeType.Absolute,54));root.RowStyles.Add(new RowStyle(SizeType.Percent,100));root.RowStyles.Add(new RowStyle(SizeType.Absolute,94));dialog.Controls.Add(root);
  var toolbar=new FlowLayoutPanel{Dock=DockStyle.Fill};toolbar.Controls.Add(new Label{Text=Loc.T("DPI pôvodnej tlačiarne:"),AutoSize=true,Margin=new Padding(0,12,8,0)});var resolution=new ModernComboBox{Width=245,DropDownStyle=ComboBoxStyle.DropDownList,Margin=new Padding(0,8,10,0)};ComboStyle(resolution);resolution.Items.AddRange(new object[]{"203 DPI",Loc.T("203,2 DPI (8 bodov/mm)"),"300 DPI",Loc.T("304,8 DPI (12 bodov/mm)"),"600 DPI",Loc.T("609,6 DPI (24 bodov/mm)")});resolution.SelectedIndex=Math.Max(0,dpi.SelectedIndex);toolbar.Controls.Add(resolution);
  toolbar.Controls.Add(Btn(Loc.T("Uložiť kópiu ZPL"),delegate{using(var save=new SaveFileDialog{Filter="ZPL (*.zpl)|*.zpl",FileName=Path.GetFileNameWithoutExtension(path)+"-kopia.zpl"})if(save.ShowDialog(dialog)==DialogResult.OK)try{Atomic(save.FileName,delegate(string output){File.WriteAllText(output,source,new System.Text.UTF8Encoding(false));});}catch(Exception ex){Error(ex);}}));root.Controls.Add(toolbar,0,0);
  var tabs=new ModernTabs{Dock=DockStyle.Fill};var page=tabs.AddPage(Loc.T("Náhľad"));var raw=tabs.AddPage(Loc.T("Zdrojový ZPL"));root.Controls.Add(tabs,0,1);var picture=new PictureBox{Dock=DockStyle.Fill,SizeMode=PictureBoxSizeMode.Zoom};page.Controls.Add(picture);var code=new TextBox{Dock=DockStyle.Fill,Multiline=true,ReadOnly=true,ScrollBars=ScrollBars.Both,WordWrap=false,Font=UiFonts.Get(10),Text=source};raw.Controls.Add(code);var info=new Label{Dock=DockStyle.Fill,Padding=new Padding(0,8,0,0)};root.Controls.Add(info,0,2);ApplyColors(dialog);
  Action refresh=delegate{if(picture.Image!=null){var previous=picture.Image;picture.Image=null;previous.Dispose();}try{string note;picture.Image=ZplImport.Render(source,Dpis[resolution.SelectedIndex],N("Width"),N("Height"),out note);info.Text=note+Loc.T("\r\nDPI sa zo ZPL spravidla nedá určiť. Zvoľte hodnotu pôvodnej tlačiarne.");info.ForeColor=dialog.ForeColor;}catch(Exception ex){info.Text=ex.Message+Loc.T("\r\nZdrojový ZPL je dostupný na druhej karte.");info.ForeColor=dark?Color.LightSalmon:Color.Firebrick;}};resolution.SelectedIndexChanged+=delegate{refresh();};refresh();try{dialog.ShowDialog(this);}finally{if(picture.Image!=null){picture.Image.Dispose();picture.Image=null;}}
 }}
}
}
