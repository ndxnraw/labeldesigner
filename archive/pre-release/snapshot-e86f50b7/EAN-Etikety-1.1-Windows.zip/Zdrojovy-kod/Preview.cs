using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace EanEtikety {
public class PreviewPanel:Panel {
 public Bitmap Image;public string Caption="";public LabelSettings Settings;
 public event Action<double,double> PositionMoved;
 bool dragging;Point mouseStart;double startX,startY;float moveScaleX,moveScaleY;
 public PreviewPanel(){DoubleBuffered=true;BackColor=Color.FromArgb(232,237,244);TabStop=true;SetStyle(ControlStyles.Selectable,true);}
 public Rectangle LabelRectangle(){if(Image==null)return Rectangle.Empty;float scale=Math.Min((ClientSize.Width-80f)/Image.Width,(ClientSize.Height-144f)/Image.Height);if(scale<=0)return Rectangle.Empty;int w=(int)(Image.Width*scale),h=(int)(Image.Height*scale);return new Rectangle((Width-w)/2,76+(Height-144-h)/2,w,h);}
 public RectangleF BarcodeRectangle(){var r=LabelRectangle();if(r.IsEmpty||Settings==null)return RectangleF.Empty;return new RectangleF(r.X+(float)(Settings.BarX/Settings.Width*r.Width),r.Y+(float)(Settings.BarY/Settings.Height*r.Height),(float)(Settings.BarWidth/Settings.Width*r.Width),(float)(Engine.BarcodeHeight(Settings)/Settings.Height*r.Height));}
 protected override void OnPaint(PaintEventArgs e){base.OnPaint(e);var g=e.Graphics;g.TextRenderingHint=System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
  using(var f=new Font("Segoe UI",11,FontStyle.Bold))g.DrawString("NÁHĽAD ETIKETY",f,Brushes.DimGray,24,16);
  g.DrawString("Kód presuniete potiahnutím myšou. Esc zruší presun.",Font,Brushes.DimGray,24,43);
  if(Image==null){g.DrawString("Upravte údaje podľa hlásenia nižšie.",Font,Brushes.DimGray,24,85);return;}
  var r=LabelRectangle();if(r.IsEmpty)return;
  using(var shadow=new SolidBrush(Color.FromArgb(205,214,226)))g.FillRectangle(shadow,r.X+6,r.Y+6,r.Width,r.Height);
  g.InterpolationMode=InterpolationMode.NearestNeighbor;g.PixelOffsetMode=PixelOffsetMode.Half;g.DrawImage(Image,r);g.DrawRectangle(Pens.SlateGray,r.X-1,r.Y-1,r.Width+1,r.Height+1);
  var bar=BarcodeRectangle();using(var pen=new Pen(Color.FromArgb(35,100,204),dragging?2:1)){pen.DashStyle=DashStyle.Dash;g.DrawRectangle(pen,bar.X,bar.Y,bar.Width,bar.Height);}
  using(var f=new Font("Segoe UI",10))using(var fmt=new StringFormat{Alignment=StringAlignment.Center})g.DrawString(Caption,f,Brushes.DimGray,new RectangleF(10,Height-37,Width-20,32),fmt);
 }
 protected override void OnMouseDown(MouseEventArgs e){base.OnMouseDown(e);if(e.Button!=MouseButtons.Left||Settings==null||!BarcodeRectangle().Contains(e.Location))return;var r=LabelRectangle();if(r.Width<=0||r.Height<=0)return;Focus();dragging=true;mouseStart=e.Location;startX=Settings.BarX;startY=Settings.BarY;moveScaleX=r.Width/(float)Settings.Width;moveScaleY=r.Height/(float)Settings.Height;Capture=true;Cursor=Cursors.SizeAll;Invalidate();}
 protected override void OnMouseMove(MouseEventArgs e){base.OnMouseMove(e);if(dragging&&Settings!=null){double maxX=Math.Floor(Math.Max(0,Settings.Width-Settings.BarWidth)*100+.00001)/100,maxY=Math.Floor(Math.Max(0,Settings.Height-Engine.BarcodeHeight(Settings))*100+.00001)/100;double x=Math.Round(Math.Max(0,Math.Min(maxX,startX+(e.X-mouseStart.X)/moveScaleX)),2),y=Math.Round(Math.Max(0,Math.Min(maxY,startY+(e.Y-mouseStart.Y)/moveScaleY)),2);if(PositionMoved!=null)PositionMoved(x,y);}else Cursor=BarcodeRectangle().Contains(e.Location)?Cursors.SizeAll:Cursors.Default;}
 protected override void OnMouseUp(MouseEventArgs e){base.OnMouseUp(e);if(e.Button==MouseButtons.Left)StopDrag();}
 protected override void OnMouseCaptureChanged(EventArgs e){base.OnMouseCaptureChanged(e);if(!Capture){dragging=false;Invalidate();}}
 protected override void OnResize(EventArgs e){StopDrag();base.OnResize(e);Invalidate();}
 void StopDrag(){dragging=false;Capture=false;Cursor=Cursors.Default;Invalidate();}
 protected override bool ProcessCmdKey(ref Message msg,Keys keyData){if(dragging&&keyData==Keys.Escape){double x=startX,y=startY;StopDrag();if(PositionMoved!=null)PositionMoved(x,y);return true;}return base.ProcessCmdKey(ref msg,keyData);}
 protected override void Dispose(bool disposing){if(disposing&&Image!=null)Image.Dispose();base.Dispose(disposing);}
}
}
