@echo off
setlocal
cd /d "%~dp0"
"%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe" /nologo /target:winexe /optimize+ /win32manifest:app.manifest /out:"..\EAN-Etikety.exe" /reference:System.Drawing.dll /reference:System.Windows.Forms.dll /reference:System.IO.Compression.dll /reference:System.IO.Compression.FileSystem.dll Engine.cs App.cs Preview.cs MoreBarcodes.cs BarcodeTables.cs AssemblyInfo.cs
if errorlevel 1 exit /b 1
echo EAN-Etikety.exe vytvoreny.
