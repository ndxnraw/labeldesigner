﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.Threading;
using System.Windows.Forms;
namespace EanEtikety {
// One STA worker for the process. A stalled driver cannot create an unbounded number
// of threads. A new request replaces pending work; running work is never aborted.
internal static class PrintWorker {
 static readonly object gate=new object();static Action pending;static object owner;
 static readonly AutoResetEvent wake=new AutoResetEvent(false);
 static PrintWorker(){var thread=new Thread(Run){IsBackground=true,Name="ND print worker"};thread.SetApartmentState(ApartmentState.STA);thread.Start();}
 public static void Queue(object key,Action action){lock(gate){owner=key;pending=action;}wake.Set();}
 public static void Cancel(object key){lock(gate){if(owner==key){pending=null;owner=null;}}}
 static void Run(){while(true){wake.WaitOne();Action action;lock(gate){action=pending;pending=null;owner=null;}if(action!=null)try{action();}catch(Exception ex){System.Diagnostics.Trace.WriteLine(ex);}}}
}
public class PrintCanvas:ScrollableControl {
 Image image;public double Zoom;public int Page;public SizeF Paper{get;set;}public RectangleF Printable{get;set;}
 public PrintCanvas(){DoubleBuffered=true;AutoScroll=true;TabStop=true;Resize+=delegate{Invalidate();};}
 public void SetPage(Image next,SizeF paper,RectangleF printable){var old=image;image=next;Paper=paper;Printable=printable;if(old!=null)old.Dispose();Invalidate();}
 public void ClearPages(){SetPage(null,SizeF.Empty,RectangleF.Empty);}
 protected override void OnPaint(PaintEventArgs e){base.OnPaint(e);if(image==null||Paper.Width<=0||Paper.Height<=0)return;
  double scale=Zoom==0?Math.Max(.01,Math.Min((ClientSize.Width-48)/Paper.Width,(ClientSize.Height-48)/Paper.Height)):Zoom*e.Graphics.DpiX/25.4;
  int w=Math.Max(1,(int)Math.Round(Paper.Width*scale)),h=Math.Max(1,(int)Math.Round(Paper.Height*scale));var extent=Zoom==0?Size.Empty:new Size(w+48,h+48);if(AutoScrollMinSize!=extent)AutoScrollMinSize=extent;
  float x=Math.Max(24,(ClientSize.Width-w)/2)+AutoScrollPosition.X,y=Math.Max(24,(ClientSize.Height-h)/2)+AutoScrollPosition.Y;e.Graphics.FillRectangle(Brushes.White,x,y,w,h);e.Graphics.DrawImage(image,new RectangleF(x,y,w,h));
  if(Focused)ControlPaint.DrawFocusRectangle(e.Graphics,new Rectangle(3,3,ClientSize.Width-6,ClientSize.Height-6));
 }
 protected override void Dispose(bool disposing){if(disposing)ClearPages();base.Dispose(disposing);}
}
internal sealed class PrintResult:IDisposable {
 public Image Image;public SizeF Paper;public RectangleF Printable;public string[] Printers,Warnings;public PaperSize[] Papers;public PrinterSettings Printer;public PageSettings Settings;public int Count;public string Error;public bool Sent,Cancelled;
 public void Dispose(){if(Image!=null){Image.Dispose();Image=null;}}
}
public class PrintPanel:UserControl {
 readonly LabelSettings snapshot;readonly PrintCanvas preview=new PrintCanvas();
 readonly ModernComboBox printers=new ModernComboBox(),zoom=new ModernComboBox(),papers=new ModernComboBox();
 readonly NumericUpDown copies=new NumericUpDown(),page=new NumericUpDown();readonly CheckBox landscape=new CheckBox();
 readonly ModernButton print=new ModernButton();readonly Label info=new Label(),paperInfo=new Label(),printerName=new Label(),pageTotal=new Label();readonly ToolTip printerTip=new UiToolTip();
 readonly FlowLayoutPanel pageTools=new FlowLayoutPanel();readonly System.Windows.Forms.Timer debounce=new System.Windows.Forms.Timer{Interval=200};
 readonly object deliveryGate=new object();PrintResult delivery;int version;bool updating,closed,started,sending,busy;PrinterSettings selectedPrinter;PageSettings selectedPage;string[] warnings=new string[0];PaperSize[] knownPapers;
 public bool Ready{get{return print.Enabled;}}public int PreviewBuilds{get;private set;}public event EventHandler PreviewReady;public event EventHandler BackRequested;
 public PrintPanel(LabelSettings settings){snapshot=CloneLabel(settings);Dock=DockStyle.Fill;Font=UiFonts.Get(10.5f);Padding=new Padding(14);
  var layout=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=3};layout.RowStyles.Add(new RowStyle(SizeType.Absolute,46));layout.RowStyles.Add(new RowStyle(SizeType.Percent,100));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,60));Controls.Add(layout);
  layout.Controls.Add(new Label{Text="ND LabelDesigner  /  "+Loc.T("Tlačiť"),Font=new Font("Segoe UI",14,FontStyle.Bold),Dock=DockStyle.Fill,TextAlign=ContentAlignment.MiddleLeft},0,0);
  var body=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=2,RowCount=1};body.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,320));body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));layout.Controls.Add(body,0,1);
  var scroll=new Panel{Dock=DockStyle.Fill,AutoScroll=true,Padding=new Padding(10),Margin=new Padding(0,0,12,0)};body.Controls.Add(scroll,0,0);var fields=new TableLayoutPanel{Dock=DockStyle.Top,AutoSize=true,ColumnCount=1};fields.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));scroll.Controls.Add(fields);
  Add(fields,new Label{Text=Loc.T("Tlačiareň"),AutoSize=true});printers.DropDownStyle=ComboBoxStyle.DropDownList;printers.AccessibleName=Loc.T("Tlačiareň");Add(fields,printers);printerName.AutoSize=true;printerName.MaximumSize=new Size(270,0);printerName.UseMnemonic=false;Add(fields,printerName);
  printers.DropDown+=delegate{int width=printers.Width;foreach(var item in printers.Items)width=Math.Max(width,TextRenderer.MeasureText(Convert.ToString(item),printers.Font).Width+40);printers.DropDownWidth=Math.Min(width,Screen.FromControl(this).WorkingArea.Width-40);};
  Add(fields,Button(Loc.T("Obnoviť tlačiarne"),delegate{StartRequest(true,false);}));Add(fields,new Label{Text=Loc.T("Počet kópií"),AutoSize=true});copies.Minimum=1;copies.Maximum=32767;copies.Value=1;copies.AccessibleName=Loc.T("Počet kópií");Add(fields,copies);
  Add(fields,new Label{Text=Loc.T("Etiketa")+": "+snapshot.Width.ToString("0.##")+" × "+snapshot.Height.ToString("0.##")+" mm",AutoSize=true,Padding=new Padding(0,6,0,6)});
  Add(fields,new Label{Text=Loc.T("Papier"),AutoSize=true});papers.DropDownStyle=ComboBoxStyle.DropDownList;papers.DisplayMember="PaperName";Add(fields,papers);landscape.Text=Loc.T("Na šírku");landscape.AutoSize=true;Add(fields,landscape);paperInfo.AutoSize=true;paperInfo.MaximumSize=new Size(270,0);Add(fields,paperInfo);
  var advanced=new CheckBox{Text=Loc.T("Rozšírené nastavenia"),AutoSize=true};Add(fields,advanced);var extra=new TableLayoutPanel{AutoSize=true,ColumnCount=1,Visible=false,Dock=DockStyle.Top};extra.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));Add(extra,Button(Loc.T("Vlastnosti tlačiarne…"),delegate{ConfigurePrinter(d=>d.ShowDialog(FindForm()));}));Add(fields,extra);advanced.CheckedChanged+=delegate{extra.Visible=advanced.Checked;};
  var right=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=2};right.RowStyles.Add(new RowStyle(SizeType.AutoSize));right.RowStyles.Add(new RowStyle(SizeType.Percent,100));body.Controls.Add(right,1,0);var tools=new FlowLayoutPanel{AutoSize=true,Dock=DockStyle.Fill,Padding=new Padding(4)};right.Controls.Add(tools,0,0);
  zoom.Width=140;zoom.DropDownStyle=ComboBoxStyle.DropDownList;zoom.Items.AddRange(new object[]{Loc.T("Celá strana"),"50 %","100 %","150 %","200 %","400 %"});zoom.SelectedIndex=0;zoom.SelectedIndexChanged+=delegate{preview.Zoom=zoom.SelectedIndex==0?0:new[]{.5,1,1.5,2,4}[zoom.SelectedIndex-1];preview.AutoScrollPosition=Point.Empty;preview.Invalidate();};tools.Controls.Add(zoom);
  pageTools.AutoSize=true;pageTools.Visible=false;pageTools.Controls.Add(new Label{Text=Loc.T("Strana:"),AutoSize=true});page.Minimum=page.Maximum=1;page.Width=65;pageTools.Controls.Add(page);pageTotal.AutoSize=true;pageTools.Controls.Add(pageTotal);tools.Controls.Add(pageTools);preview.Dock=DockStyle.Fill;right.Controls.Add(preview,0,1);
  var footer=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=2};footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));footer.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));layout.Controls.Add(footer,0,2);info.Dock=DockStyle.Fill;info.AutoEllipsis=true;info.TextAlign=ContentAlignment.MiddleLeft;footer.Controls.Add(info,0,0);var actions=new FlowLayoutPanel{AutoSize=true,Dock=DockStyle.Fill,WrapContents=false};footer.Controls.Add(actions,1,0);var back=Button(Loc.T("Späť do editora"),Back);back.Width=160;actions.Controls.Add(back);print.Text=Loc.T("Tlačiť");print.Size=new Size(130,42);print.FlatStyle=FlatStyle.Flat;print.Click+=delegate{Submit();};actions.Controls.Add(print);print.Enabled=false;
  printers.SelectedIndexChanged+=delegate{if(!updating)SelectPrinter(Convert.ToString(printers.SelectedItem));};papers.SelectedIndexChanged+=delegate{if(!updating&&selectedPage!=null&&papers.SelectedItem is PaperSize){selectedPage.PaperSize=(PaperSize)papers.SelectedItem;Schedule();}};landscape.CheckedChanged+=delegate{if(!updating&&selectedPage!=null){selectedPage.Landscape=landscape.Checked;Schedule();}};page.ValueChanged+=delegate{if(!updating)Schedule();};debounce.Tick+=delegate{debounce.Stop();StartRequest(false,false);};info.Text=Loc.T("Načítavam tlačiarne…");
 }
 public static LabelSettings CloneLabel(LabelSettings source){using(var stream=new System.IO.MemoryStream()){var xml=new System.Xml.Serialization.XmlSerializer(typeof(LabelSettings));xml.Serialize(stream,source);stream.Position=0;return (LabelSettings)xml.Deserialize(stream);}}
 protected override void OnLoad(EventArgs e){base.OnLoad(e);if(!started){started=true;BeginInvoke((Action)delegate{StartRequest(true,false);});}}
 static void Add(TableLayoutPanel p,Control c){c.Dock=DockStyle.Top;c.Margin=new Padding(0,4,0,6);c.TabIndex=p.Controls.Count;p.Controls.Add(c,0,p.RowCount++);p.RowStyles.Add(new RowStyle(SizeType.AutoSize));}
 static ModernButton Button(string text,Action action){var b=new ModernButton{Text=text,Height=38,FlatStyle=FlatStyle.Flat};b.Click+=delegate{action();};return b;}
 public void Style(Action<Control> apply,bool dark){apply(this);preview.BackColor=dark?Color.FromArgb(14,21,32):Color.FromArgb(233,237,243);print.BackColor=StudioTheme.Accent;print.ForeColor=Color.White;print.FlatAppearance.BorderColor=StudioTheme.Accent;}
 void Schedule(){if(sending)return;version++;print.Enabled=false;preview.ClearPages();info.Text=Loc.T("Pripravujem náhľad…");debounce.Stop();debounce.Start();}
 public void SelectPrinter(string name){if(sending)return;selectedPrinter=null;selectedPage=null;knownPapers=null;updating=true;printers.SelectedItem=name;updating=false;printerName.Text=name;printerTip.SetToolTip(printers,name);printerTip.SetToolTip(printerName,name);StartRequest(false,false,name);}
 public void RefreshPreview(){StartRequest(false,false);}
 void StartRequest(bool discover,bool send){StartRequest(discover,send,null);}
 void StartRequest(bool discover,bool send,string requested){if(closed||sending&&!send)return;debounce.Stop();int ticket=++version;string name=requested??Convert.ToString(printers.SelectedItem);var printer=selectedPrinter==null?null:(PrinterSettings)selectedPrinter.Clone();var settings=selectedPage==null?null:(PageSettings)selectedPage.Clone();var cachedPapers=discover?null:knownPapers;int index=(int)page.Value-1;short count=(short)copies.Value;
  busy=true;print.Enabled=false;if(!send)preview.ClearPages();info.Text=Loc.T(send?"Odosielam do tlačiarne…":discover?"Načítavam tlačiarne…":"Pripravujem náhľad…");if(send){sending=true;printers.Enabled=papers.Enabled=landscape.Enabled=copies.Enabled=false;}
  PrintWorker.Queue(this,delegate{var result=new PrintResult();try{
   if(discover){var list=new List<string>();foreach(string item in PrinterSettings.InstalledPrinters)list.Add(item);result.Printers=list.ToArray();}
   using(var doc=new LabelPrintDocument(snapshot)){if(printer==null){printer=new PrinterSettings();if(!string.IsNullOrEmpty(name))printer.PrinterName=name;settings=(PageSettings)printer.DefaultPageSettings.Clone();settings.Margins=new Margins(0,0,0,0);}printer.Copies=count;doc.PrinterSettings=printer;doc.DefaultPageSettings=settings;var readyPage=(PageSettings)settings.Clone();readyPage.PaperSize=settings.PaperSize;readyPage.Landscape=settings.Landscape;result.Printer=(PrinterSettings)printer.Clone();result.Settings=readyPage;if(cachedPapers!=null)result.Papers=cachedPapers;else{var sizes=new List<PaperSize>();if(printer.IsValid)foreach(PaperSize size in printer.PaperSizes)sizes.Add(size);result.Papers=sizes.ToArray();}result.Count=doc.PageCount;
    doc.ValidatePrinter();result.Warnings=doc.PrintWarnings().ToArray();if(send){doc.PrintController=new StandardPrintController();doc.Print();result.Cancelled=doc.Cancelled;result.Sent=!doc.Cancelled;}else{doc.PreviewPageIndex=Math.Max(0,Math.Min(doc.PageCount-1,index));var controller=new PreviewPrintController{UseAntiAlias=true};doc.PrintController=controller;PreviewPageInfo[] pages=null;try{doc.Print();pages=controller.GetPreviewPageInfo();if(pages.Length==0)throw new InvalidOperationException(Loc.T("Dokument neobsahuje nič na tlač."));var metafile=pages[0].Image as System.Drawing.Imaging.Metafile;if(metafile!=null&&metafile.GetMetafileHeader().MetafileSize>32*1024*1024)throw new InvalidOperationException(Loc.T("Náhľad prekročil limit 32 MB. Zjednodušte dokument."));result.Image=pages[0].Image;result.Paper=new SizeF(pages[0].PhysicalSize.Width*.254f,pages[0].PhysicalSize.Height*.254f);var a=settings.PrintableArea;result.Printable=new RectangleF(a.X*.254f,a.Y*.254f,a.Width*.254f,a.Height*.254f);}finally{if(pages==null)pages=controller.GetPreviewPageInfo();for(int i=0;i<pages.Length;i++)if(pages[i].Image!=result.Image)pages[i].Image.Dispose();}}}
  }catch(Exception ex){result.Error=ex.Message;}Deliver(ticket,result);});
 }
 void Deliver(int ticket,PrintResult result){lock(deliveryGate){if(closed||ticket!=version){result.Dispose();return;}if(delivery!=null)delivery.Dispose();delivery=result;}try{BeginInvoke((Action)delegate{PrintResult ready;lock(deliveryGate){if(delivery!=result)return;ready=delivery;delivery=null;}if(ready==null)return;using(ready){if(closed||ticket!=version)return;ApplyResult(ready);}});}catch(InvalidOperationException){lock(deliveryGate){if(delivery==result){delivery=null;result.Dispose();}}}}
 void ApplyResult(PrintResult result){updating=true;try{if(result.Printers!=null){printers.Items.Clear();printers.Items.AddRange(result.Printers);}if(result.Printer!=null&&result.Papers!=null){selectedPrinter=result.Printer;selectedPage=result.Settings;knownPapers=result.Papers;printerName.Text=selectedPrinter.PrinterName;printerTip.SetToolTip(printers,printerName.Text);printerTip.SetToolTip(printerName,printerName.Text);if(!printers.Items.Contains(printerName.Text))printers.Items.Add(printerName.Text);printers.SelectedItem=printerName.Text;papers.Items.Clear();PaperSize chosen=null;foreach(var size in result.Papers){papers.Items.Add(size);if(size.RawKind==selectedPage.PaperSize.RawKind&&size.Width==selectedPage.PaperSize.Width&&size.Height==selectedPage.PaperSize.Height)chosen=size;}if(chosen==null){chosen=selectedPage.PaperSize;papers.Items.Add(chosen);}papers.SelectedItem=chosen;landscape.Checked=selectedPage.Landscape;}
   page.Maximum=Math.Max(1,result.Count);pageTools.Visible=result.Count>1;pageTotal.Text="/ "+result.Count;warnings=result.Warnings??new string[0];
   if(result.Error!=null){info.Text=Loc.T(sending?"Tlač sa nepodarila: ":"Náhľad nie je dostupný: ")+result.Error;print.Enabled=false;}
   else if(result.Cancelled){info.Text=Loc.T("Tlač bola zrušená.");print.Enabled=true;}else if(result.Sent){info.Text=Loc.T("Úloha bola odoslaná do tlačového systému Windows.");print.Enabled=true;}
   else{preview.SetPage(result.Image,result.Paper,result.Printable);result.Image=null;preview.Page=(int)page.Value-1;paperInfo.Text=Loc.T("Papier")+": "+result.Paper.Width.ToString("0.##")+" × "+result.Paper.Height.ToString("0.##")+" mm\r\n"+Loc.T("Mierka tlače: 100 %");info.Text=string.Join(" ",warnings);printerTip.SetToolTip(info,info.Text);print.Enabled=true;PreviewBuilds++;}
  }finally{updating=false;sending=false;busy=false;printers.Enabled=papers.Enabled=landscape.Enabled=copies.Enabled=true;}if(PreviewReady!=null)PreviewReady(this,EventArgs.Empty);
 }
 public bool ConfigurePrinter(Func<PrintDialog,DialogResult> show){if(selectedPrinter==null||sending||busy)return false;try{using(var dialog=new PrintDialog{PrinterSettings=(PrinterSettings)selectedPrinter.Clone(),UseEXDialog=true,AllowSomePages=false,AllowSelection=false,AllowCurrentPage=false,AllowPrintToFile=false}){dialog.PrinterSettings.DefaultPageSettings.PaperSize=selectedPage.PaperSize;dialog.PrinterSettings.DefaultPageSettings.Landscape=selectedPage.Landscape;dialog.PrinterSettings.Copies=(short)copies.Value;if(show(dialog)!=DialogResult.OK)return false;selectedPrinter=(PrinterSettings)dialog.PrinterSettings.Clone();selectedPage=(PageSettings)dialog.PrinterSettings.DefaultPageSettings.Clone();knownPapers=null;copies.Value=Math.Max(1,(int)selectedPrinter.Copies);StartRequest(false,false);return true;}}catch(Exception ex){info.Text=ex.Message;return false;}}
 void Submit(){if(!Ready||sending)return;if(warnings.Length>0&&UiMessageBox.Show(this,string.Join("\r\n",warnings)+"\r\n"+Loc.T("Pokračovať v tlači?"),Loc.T("Tlačiť"),MessageBoxButtons.YesNo,MessageBoxIcon.Warning)!=DialogResult.Yes)return;StartRequest(false,true);}
 void Back(){if(sending){info.Text=Loc.T("Odosielanie už prebieha. Úlohu môžete zrušiť vo fronte Windows.");}if(BackRequested!=null)BackRequested(this,EventArgs.Empty);}
 protected override bool ProcessCmdKey(ref Message msg,Keys key){if(key==Keys.Escape){Back();return true;}return base.ProcessCmdKey(ref msg,key);}
 protected override void Dispose(bool disposing){if(disposing){lock(deliveryGate){closed=true;version++;if(delivery!=null){delivery.Dispose();delivery=null;}}PrintWorker.Cancel(this);debounce.Dispose();printerTip.Dispose();preview.ClearPages();}base.Dispose(disposing);}
}
}
